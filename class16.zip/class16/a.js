//search 
//let s="Find me"
//i want to find whether there is me or not in the give string 
// for(let i=0;i<s.length;i++){
//     if(s[i]=="m" || s[i]=="e"){
//         console.log("yes its there",s[i])
//     }
//     else{
//         console.log("no")
//     }
// }

//method1:// 
// let pat=/Me/
//synatx search 
//String.search(patteren)
// let res=s.search(pat)
// console.log(res) 

//method2
// let a=new RegExp(/me/)
// let r1=s.search(a)
// console.log(r1) 


//
// let s="the order number is 234"
// let pat=/\d[0-9]/
// let r1=s.search(pat)
// console.log(r1) 

// let s1="this is my mailid a@gmail.com"
// let s2="ex123cler" 

//test 
//synatx:pat.test("string")

// let s="Hellowworld"
// //wap to find a pattern where we have to check wherther it has only alphabets 
// let pat=/^[A-Za-z]+$/
// console.log(pat.test(s)) 

//wap to check string is a valid phone number or not

// let num1="123-456-7890"
// let num2="(123) 456-7890"
// let num3="1234567890"

// // let pat=/^[0-9]-+$/
// let pat=/^(\d{3})-(\d{3})-(\d{4})/
// console.log(pat.test(num))

// //wapwap to check valid email address  

// function isValidEmail(email) {
//     const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
//     return emailPattern.test(email);
// }
// const email = prompt("Enter an email address: ");
// if (isValidEmail(email)) {
//     console.log(`${email} is a valid email address.`);
// } else {
//     console.log(`${email} is not a valid email address.`);
// } 

//create frontend form and valid the email using regular expression  

//create front-end form and check whether it has has number 

// exce 
// syntax:pattern.exce("pattern")
//wap to extract first word from a sentence 

// let s="Hello world"
// let pat=/\b\w+\b/
// let res=pat.exec(s)
// console.log(res[0])

//wap to extract digits from a string 
let msg=" the cost is 100rs"
let pat=/\d+/
let res=pat.exec(msg)
console.log(res)

3)Extracting email from a string 
let s="contact me at a@gmail.com" 
function extractEmails(text) {
    const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    return text.match(emailPattern) || [];
}
const inputText = "If any problem contact me at sri@gmail.com";
const emails = extractEmails(inputText);
console.log("Extracted Emails:", emails); 
4)extracting date in yyyy-mm-dd 
let s="todays date is 2025-04-04" 

what will be the output of this?
"the price is 250dollers"
pat=r"/d" 

exact all the words from the given senetence 
s="hello, this is a test sentence!"

find consecutive digits 
text="I have 12 apples, 3 bananas, and 456 organes" 
15min 
4:24 